#!/usr/bin/env python
# coding: utf-8

# ## Objective
# The objective of this script is to develop a dynamic web application that enables users to build and evaluate machine learning models without writing code. By allowing users to select features of interest from a dataset, the application will automatically generate a predictive model based on the highest-variance features. It will also provide intuitive visualizations to help users assess the model's performance. This tool aims to make model building and evaluation accessible to a broader audience by offering a graphic user interface that simplifies the process of data exploration, feature selection, model training, and result interpretation.

# In[1]:


import pandas as pd
import plotly.express as px
from dash import Input, Output, dcc, html
from jupyter_dash import JupyterDash
from scipy.stats.mstats import trimmed_var
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


# In[2]:


#load data
def wrangle(filepath):

    """Read loan50 data file into ``DataFrame``.

    Returns only Households with a higher debt-to-income ratio >0.4

    Parameters
    ----------
    filepath : str
        Location of CSV file.
    """
    df=pd.read_csv(filepath)
    #filtering data; Households with a higher debt-to-income ratio
    mask= df["debt_to_income"] > 0.4
    df=df[mask]
    
    
    return df


# In[3]:


#load data using the function
df = wrangle("C:/Users/user/Desktop/Datasets/loan50.csv")

print("df type:", type(df))
print("df shape:", df.shape)
df.head()


# In[4]:


# Drop non-numeric columns
df = df.select_dtypes(include=[int, float])
df.info()


# In[5]:


# Instantiate a JupyterDash application and assign it to the variable name app.
app = JupyterDash(__name__)

print("app type:", type(app))


# In[6]:


#start building the layout of your app by creating a Div object that has two child objects: an H1 header that reads "Survey of Consumer Finances" and an H2 header that reads "High Variance Features".

app.layout = html.Div(
    [
        #application title
        html.H1("Survey of Loan Applicants"),
        #Bar chart element
        html.H2("High Variance Features"),
        #Bar chart graph
        dcc.Graph(id = "bar-chart"),
        # Use your serve_bar_chart function to add a bar chart to "bar-chart". 
         dcc.RadioItems(
            options =[
                {"label": "trimmed", "value": True},
                {"label": "not trimmed", "value": False}
            
            ],
            value= True,
            id="trim-button"
        
        ), ##add button
        #k-means slider
        html.H2("k-means clusterng"),
        html.H3("number of clusters (k)"),
        dcc.Slider(min=2,max=12,step=1,value=2,id="k-slider"),
        html.Div(id = "metrics"),
        #pca scatter
        dcc.Graph(id = "pca-scatter")
    
    
    
    
    ]

)


# In[7]:


#app.run_server(host="0.0.0.0", mode="external")


# In[8]:


# Create a get_high_var_features function that returns the five highest-variance features in a DataFrame. Use the docstring for guidance.
def get_high_var_features(trimmed=True,return_feat_names=True):

    """Returns the five highest-variance features of ``df``.

    Parameters
    ----------
    trimmed : bool, default=True
        If ``True``, calculates trimmed variance, removing bottom and top 10%
        of observations.

    return_feat_names : bool, default=False
        If ``True``, returns feature names as a ``list``. If ``False``
        returns ``Series``, where index is feature names and values are
        variances.
    """
    #calculate variance
    if trimmed:
        top_five_features = (
            df.apply(trimmed_var).sort_values().tail(5)
        
        )
    else:
            df.var().sort_values().tail(5)
    #extract names
    if return_feat_names:
        top_five_features = top_five_features.index.to_list()
            
        
    return top_five_features


# In[9]:


get_high_var_features(trimmed=True,return_feat_names=True)


# In[10]:


#Add a callback decorator to your serve_bar_chart function. The callback input should be the value returned by "trim-button", and the output should be directed to "bar-chart".

@app.callback(
    Output("bar-chart", "figure"), Input("trim-button", "value")

)

#Create a serve_bar_chart function that returns a plotly express bar chart of the five highest-variance features. You should use get_high_var_features as a helper function. Follow the docstring for guidance.

def serve_bar_chart(trimmed=True):

    """Returns a horizontal bar chart of five highest-variance features.

    Parameters
    ----------
    trimmed : bool, default=True
        If ``True``, calculates trimmed variance, removing bottom and top 10%
        of observations.
    """
    #get features
    top_five_features= get_high_var_features(trimmed = trimmed, return_feat_names = False)
    
    #build bar chart
    # Create horizontal bar chart of `top_ten_trim_var`
    fig = px.bar( x= top_five_features,y=top_five_features.index,orientation = "h" )
    fig.update_layout(xaxis_title = "Trimmed variance", yaxis_title = "Feature")

    return fig


# In[11]:


serve_bar_chart(trimmed=True)


# In[12]:


# Create a get_model_metrics function that builds, trains, and evaluates KMeans model. Use the docstring for guidance. Note that, like the model you made in the last lesson, your model here should be a pipeline that includes a StandardScaler. Once you're done, submit your function to the grader.

def get_model_metrics(trimmed = True, k=2, return_metrics=False):

    """Build ``KMeans`` model based on five highest-variance features in ``df``.

    Parameters
    ----------
    trimmed : bool, default=True
        If ``True``, calculates trimmed variance, removing bottom and top 10%
        of observations.

    k : int, default=2
        Number of clusters.

    return_metrics : bool, default=False
        If ``False`` returns ``KMeans`` model. If ``True`` returns ``dict``
        with inertia and silhouette score.

    """
    #Get high var features
    features=get_high_var_features(trimmed = trimmed, return_feat_names = True)
    #create feature matrix
    X = df[features]
    #build model
    model = make_pipeline(StandardScaler(),KMeans(n_clusters=k,random_state=42))
    model.fit(X)
    
    if return_metrics:
        #calc inertia
        i=model.named_steps["kmeans"].inertia_
        #calc silhouette scores
        ss= silhouette_score(X,model.named_steps["kmeans"].labels_)
        #put results into a dictionary
        metrics = {
            "inertia": round(i),
            "silhouette": round(ss,3)
        }
        return metrics
    
    return model


# In[13]:


get_model_metrics(trimmed = True, k=5, return_metrics=False)


# In[14]:


#Add a callback decorator to your serve_metrics function. The callback inputs should be the values returned by "trim-button" and "k-slider", and the output should be directed to "metrics".

@app.callback(
    Output("metrics", "children"), 
    Input("trim-button", "value"),
    Input("k-slider", "value")

)


#Create a serve_metrics function. It should use your get_model_metrics to build and get the metrics for a model, and then return two objects: An H3 header with the model's inertia and another H3 header with the silhouette score.

def serve_metrics(trimmed = True, k= 2):

    """Returns list of ``H3`` elements containing inertia and silhouette score
    for ``KMeans`` model.

    Parameters
    ----------
    trimmed : bool, default=True
        If ``True``, calculates trimmed variance, removing bottom and top 10%
        of observations.

    k : int, default=2
        Number of clusters.
    """
    metrics = get_model_metrics(trimmed = True, k=k, return_metrics=True)
    
    #add metrics to HTML
    text = [
        html.H3(f"Inertia: {metrics['inertia']}"),
         html.H3(f"silhouette score: {metrics['silhouette']}")
        
    
    ]
    return text


# In[15]:


#Create a function get_pca_labels that subsets a DataFrame to its five highest-variance features, reduces those features to two dimensions using PCA, and returns a new DataFrame with three columns: "PC1", "PC2", and "labels". This last column should be the labels determined by a KMeans model. Your function should you get_high_var_features and get_model_metrics as helpers. Refer to the docstring for guidance.

def get_pca_labels(trimmed= True, k=2):

    """
    ``KMeans`` labels.

    Parameters
    ----------
    trimmed : bool, default=True
        If ``True``, calculates trimmed variance, removing bottom and top 10%
        of observations.

    k : int, default=2
        Number of clusters.
    """
    #get features
    features= get_high_var_features(trimmed = trimmed, return_feat_names = True)
    #create feature matrix
    X = df[features]
    #build model
    # Instantiate transformer
    transformer = PCA(n_components=2, random_state=42)
    # Transform `X`
    X_t = transformer.fit_transform(X)
    # Put `X_t` into DataFrame
    X_pca = pd.DataFrame(X_t, columns = ["PC1", "PC2"])
    #add labels
    model = get_model_metrics(trimmed= True, k=2,return_metrics=False)
    X_pca["labels"] = model.named_steps["kmeans"].labels_.astype(str)
    X_pca.sort_values("labels", inplace = True)


    
    return X_pca


# In[16]:


#Add a callback decorator to your serve_scatter_plot function. The callback inputs should be the values returned by "trim-button" and "k-slider", and the output should be directed to "pca-scatter".
@app.callback(
    Output("pca-scatter", "figure"), 
    Input("trim-button", "value"),
    Input("k-slider", "value")

)

#Create a function serve_scatter_plot that creates a 2D scatter plot of the data used to train a KMeans model, along with color-coded clusters. Use get_pca_labels as a helper. Refer to the docstring for guidance.
def serve_scatter_plot(trimmed=True, k=2):

    """Build 2D scatter plot of ``df`` with ``KMeans`` labels.

    Parameters
    ----------
    trimmed : bool, default=True
        If ``True``, calculates trimmed variance, removing bottom and top 10%
        of observations.

    k : int, default=2
        Number of clusters.
    """
    fig = px.scatter(
    data_frame= get_pca_labels(trimmed=trimmed,k=k),
    x="PC1",
    y="PC2",
    color="labels",
    title= "PCA Representation of Clusters"

)
    fig.update_layout(xaxis_title = "PC1", yaxis_title = "PC2")

    return fig


# In[17]:


serve_scatter_plot(trimmed=True, k=2) # remember to comment out


# In[19]:


#Application Deployment
app.run_server(host="127.0.0.1", mode="external")


# In[ ]:





# In[ ]:




